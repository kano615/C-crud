﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication18
{
    public partial class Form1 : Form
    {
        public static int tr;
        public static int rp=0;
        public static SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True;User Instance=True");
        public static String sql = "select * from employee";
        public static SqlDataAdapter da = new SqlDataAdapter(sql, cn);
        public static DataTable dt = new DataTable();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            tr = dt.Rows.Count - 1;
        }
        private void  loaddata()
        {
            String sql = "select * from employee";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String sql = "insert into employee values('" + textBox2.Text + "','" + textBox3.Text + "')";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            loaddata();

            textBox2.Text = textBox3.Text ="";
            textBox2.Focus();
            
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox1.Text != "")
            {
                try
                {

                    String sql = "select * from employee where rn='" + textBox1.Text + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    textBox2.Text = dt.Rows[0][0].ToString();
                    textBox3.Text = dt.Rows[0][1].ToString();
                }
                catch (Exception e1)
                {
                    Console.Write(e1);
                }
            }
            else
            {
                textBox2.Text = textBox3.Text = "";

            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String sql = "delete from employee where rn='" + textBox2.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            loaddata();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            rp = 0;
            if (rp == 0)
            {
                textBox2.Text = dt.Rows[rp][0].ToString();
                textBox3.Text = dt.Rows[rp][1].ToString();
            }
            else
            {
                MessageBox.Show("not avaliable record");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
                rp++;
                if (rp>tr)
                {
                    textBox2.Text = textBox3.Text = "";
                    
                    MessageBox.Show("not avaliable record");

                }
                else
                {
                    textBox2.Text = dt.Rows[rp][0].ToString();
                    textBox3.Text = dt.Rows[rp][1].ToString();
                }
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            rp =tr;
            textBox2.Text = dt.Rows[rp][0].ToString();
            textBox3.Text = dt.Rows[rp][1].ToString();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            rp--;
            if (rp<0)
            {
                textBox2.Text = textBox3.Text = "";
                MessageBox.Show("please retrive ");
            }
            else
            {
                textBox2.Text = dt.Rows[rp][0].ToString();
                textBox3.Text = dt.Rows[rp][1].ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String sql = "update employee set name='"+textBox3.Text + "' where rn='"+textBox2.Text+"'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            textBox2.Text = textBox3.Text = "";
            loaddata();
        }
    }
}
